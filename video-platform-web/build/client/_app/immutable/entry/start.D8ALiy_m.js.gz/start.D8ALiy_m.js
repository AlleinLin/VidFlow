import{l as s,a}from"../chunks/taLHk_yT.js";export{s as load_css,a as start};
